from django.db import models
from .hospital import Hospital
from django.urls import reverse
from django.conf import settings


class Doctor(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    doctor_id = models.CharField(max_length=20)
    name = models.CharField(max_length=250)
    works_in = models.ForeignKey(Hospital, on_delete=models.CASCADE)
    trained_in = models.CharField(max_length=250)
    #cert_date = models.DateField(verbose_name='Certification Date')
    #cert_exp = models.DateField(verbose_name='Certification Expires')
    #slug = models.SlugField()

    def __str__(self):
        return self.name
    
    def get_absolute_url(self):
        return reverse('hospitaldb:doctor-bio', kwargs={'pk': self.pk})

    class Meta:
        ordering = ['name']